package com.test;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/answer")

public class AnswerServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        String answer = req.getParameter("answer");

        List<Integer> ids = (List<Integer>) session.getAttribute("questionIds");
        Integer index = (Integer) session.getAttribute("currentIndex");
        Map<Integer, String> answers = (Map<Integer, String>) session.getAttribute("answers");

        answers.put(ids.get(index), answer);
        session.setAttribute("answers", answers);

        index++;
        session.setAttribute("currentIndex", index);

        if (index >= ids.size()) resp.sendRedirect("result");
        else resp.sendRedirect("question");
    }
}
