package com.test;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username = req.getParameter("username");
		String password = req.getParameter("password");

		try (Connection con = DBConnection.getConnection()) {
			PreparedStatement ps = con.prepareStatement("SELECT * FROM users WHERE username=? AND password=?");
			ps.setString(1, username);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				HttpSession session = req.getSession();
				session.setAttribute("userId", rs.getInt("id"));

				List<Integer> questionIds = new ArrayList<>();
				PreparedStatement psQ = con.prepareStatement("SELECT id FROM questions ORDER BY RAND() LIMIT 3");
				ResultSet rsQ = psQ.executeQuery();
				while (rsQ.next())
					questionIds.add(rsQ.getInt(1));

				session.setAttribute("questionIds", questionIds);
				session.setAttribute("currentIndex", 0);
				session.setAttribute("answers", new HashMap<Integer, String>());

				resp.sendRedirect("question");
			} else {
				RequestDispatcher rd = req.getRequestDispatcher("index.html");

				// rd.include(req, resp);
				rd.forward(req, resp);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
