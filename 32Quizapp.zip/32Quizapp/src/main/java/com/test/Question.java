package com.test;

public class Question {
    private int id;
    private String text;
    private String optionA, optionB, optionC, optionD, correctOption;

    public Question() {}

    public Question(int id, String text, String optionA, String optionB, String optionC, String optionD, String correctOption) {
        this.id = id; this.text = text; this.optionA = optionA; this.optionB = optionB;
        this.optionC = optionC; this.optionD = optionD; this.correctOption = correctOption;
    }

}

