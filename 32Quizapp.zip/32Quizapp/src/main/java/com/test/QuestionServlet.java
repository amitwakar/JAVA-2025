package com.test;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/question")
public class QuestionServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        List<Integer> ids = (List<Integer>) session.getAttribute("questionIds");
        Integer index = (Integer) session.getAttribute("currentIndex");

        if (ids == null || index == null || index >= ids.size()) {
            resp.sendRedirect("result"); return;
        }

        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM questions WHERE id=?");
            ps.setInt(1, ids.get(index));
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                PrintWriter out = resp.getWriter();
                resp.setContentType("text/html");
                out.println("<html><head>");
                out.println("<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css'>");
                out.println("</head><body class='bg-light container mt-5'>");
                out.println("<h3>Question " + (index+1) + ": " + rs.getString("question_text") + "</h3>");
                out.println("<form method='post' action='answer'>");
                out.println("<input type='radio' name='answer' value='A' required> " + rs.getString("option_a") + "<br>");
                out.println("<input type='radio' name='answer' value='B'> " + rs.getString("option_b") + "<br>");
                out.println("<input type='radio' name='answer' value='C'> " + rs.getString("option_c") + "<br>");
                out.println("<input type='radio' name='answer' value='D'> " + rs.getString("option_d") + "<br><br>");
                out.println("<button class='btn btn-primary'>Next</button>");
                out.println("</form></body></html>");
            }
        } catch (Exception e) { e.printStackTrace(); }
    }
}
