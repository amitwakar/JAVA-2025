package com.test;

public class Result {
    private int id;
    private int userId;
    private int score;

    public Result() {}
    public Result(int id, int userId, int score) {
        this.id = id; this.userId = userId; this.score = score;
    }

}

