package com.test;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/result")
public class ResultServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        Map<Integer, String> answers = (Map<Integer, String>) session.getAttribute("answers");
        int score = 0;

        try (Connection con = DBConnection.getConnection()) {
            for (Map.Entry<Integer, String> e : answers.entrySet()) {
                PreparedStatement ps = con.prepareStatement("SELECT correct_option FROM questions WHERE id=?");
                ps.setInt(1, e.getKey());
                ResultSet rs = ps.executeQuery();
                if (rs.next() && rs.getString(1).equalsIgnoreCase(e.getValue())) score++;
            }

            PreparedStatement psSave = con.prepareStatement("INSERT INTO results(user_id,score) VALUES(?,?)");
            psSave.setInt(1, userId); psSave.setInt(2, score);
            psSave.executeUpdate();

            PrintWriter out = resp.getWriter();
            resp.setContentType("text/html");
            out.println("<html><head><link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css'></head>");
            out.println("<body class='bg-light container mt-5'><h3>Your Score: " + score + "</h3>");
            out.println("<a href='logout' class='btn btn-danger'>Logout</a></body></html>");
        } catch (Exception e) { e.printStackTrace(); }
    }
}

